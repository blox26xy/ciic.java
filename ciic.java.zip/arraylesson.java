

public class arraylesson {
    public static void main(String[] args) {
        int[] i = new int[3];
        i[0] = 1;
        i[1] = 2;
        i[2] = 3;
        System.out.println("Array elements:");
        for (int number : numbers) {
            System.out.println(number);
        }   
    }
        
}
