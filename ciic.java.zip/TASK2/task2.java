public class task2 {

        public static void main(String[] args) {

            String c = "H3110 ";
            char w = 'w';
            byte zero = 0;
            // int i = 1;
            String r = "rld";
            float f = 2.0f;
            boolean yes = true;

            String result = c + w + zero + r + " " + f + " " + yes;

            //  String result = b + s + i + f + c + bool;
            //  String result = c + w + zero + r + f + " " + yes;
            System.out.println( result );

            // H3110 w0rld 2.0 true
        }
    }