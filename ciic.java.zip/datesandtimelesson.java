import java.time.LocalTime;

public class datesandtimelesson {
    public static void main(String[] args) {
    //    System.out.println(java.time.LocalDate.now());
    //    System.out.println(java.time.LocalTime.now());
    //    System.out.println(java.time.LocalDateTime.now());  
    
    LocalTime time1 = LocalTime.of(6, 15); // hour, minute
    System.out.println(time1);
    }
}
