public class arraylist {
    public static void main(String[] args) {
        list2.add(e:54);
        list2.add(e:4);
        System.out.println(list2);
    }
}
